function player1(name, height, country) {

    alert(name + " " + height + " " + country);
}

player1("keenan","5,9","US")

